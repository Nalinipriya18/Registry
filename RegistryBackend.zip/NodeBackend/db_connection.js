var mysql = require('mysql');
const express = require('express');
const cors = require('cors');
const mv = require("mv");
var multer = require("multer");
const IncomingForm = require("formidable").IncomingForm;
const { response } = require("express");
var corsOptions = {
  origin: "*",
  optionsSuccessStatus: 200,
};

const bodyParser = require('body-parser');
//const jwt = require('jsonwebtoken');
//const util = require('./util');


const app = express();
app.use(cors(corsOptions));
app.use(bodyParser.json());       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
}));
const port = process.env.PORT || 4000;

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "mysql",
  database: "mydb"
});



con.connect(function (err) {
  if (err) throw err;
  console.log("Connected!");
  /* var sql = "CREATE TABLE employee (name VARCHAR(255), address VARCHAR(255))";
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table created");
  }); */ //create table

  app.use(bodyParser.urlencoded({ extended: true }));
  app.set("view engine", "ejs");
 /*  app.post('/postImage', function (req, res) {
    var name = req.body.name;
    var image = req.body.image;
    var sql = `INSERT INTO images (name, image) VALUES (?,?)`;
    con.query(sql, [name, image], function (err, result) {
      if (err) throw err;
      console.log("1 record inserted");
      return res.send(result);
    });

  }); */
  app.use(cors());
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "upload");
  },
  filename: function (req, file, cb) {
    cb(null,file.originalname);
  },
});
var upload = multer({ storage: storage }).single("file");
app.use(express.static(__dirname + '/upload'));
app.post("/postImage", function (req, res) {
  upload(req, res, function (err) {
    console.log("file", req.file);
    if (req.file != undefined) {
      if (err instanceof multer.MulterError) {
        return res.status(500).json(err);
      } else if (err) {
        return res.status(500).json(err);
      }
      return res.status(200).send(req.file);
    }
    else
    {
      var message="Image Should not be empty";
      return res.send(message);
    }
  });
});

   app.post('/postRegistry', function (req, res) {
    var firstName = req.body.firstName;
    var lastName = req.body.lastName;
    var password= req.body.password;
    var cpassword = req.body.cpassword;
    var email = req.body.email;
   // var id = req.body.id;
    var birth_date= req.body.birth_date;
    var imageName = req.body.imageName;
    var sql = `INSERT INTO registry (firstName,lastName,password,cpassword,email,birth_date,imageName) VALUES (?,?,?,?,?,?,?  )`;
    con.query(sql, [firstName,lastName,password,cpassword,email,birth_date,imageName], function (err, result) {
      if (err) throw err;
      console.log("1 record inserted");
      return res.send(result);
    });

  });

  if (err) throw err;
  app.get('/getRegistryList', function (req, res) {
    con.query("SELECT * FROM registry", function (err, result, fields) {
      if (err) throw err;
      console.log(result);
      return res.send(result);
    });
  })
/* app.get('/getImage', function (req, res) {
    con.query("SELECT * FROM image", function (err, result, fields) {
      if (err) throw err;
      console.log(result);
      return res.send(result);
    });
  }) */
});
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");
/* app.post('/updateEmployee', function (req, res) {
  // var id = req.body.id;
  var sql = `UPDATE employee
SET name = ?,address=?
WHERE id = ?`;

  let data = [req.body.name, req.body.address, req.body.id];
  console.log("data update", data);
  con.query(sql, data, (error, results, fields) => {
    if (error) {
      return console.error(error.message);
    }
    console.log('Rows affected:', results.affectedRows);
    return res.send(results);
  });
});
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "ejs");
app.delete('/deleteEmployee', function (req, res) {
  // var id = ;
  var sql = `delete from employee
WHERE id = ?`;
  let data = [req.body.id];
  con.query(sql, data, (error, results, fields) => {
    if (error)
      return console.error(error.message);

    console.log('Deleted Row(s):', results.affectedRows);
    return res.send(results);
  });
});
 */app.listen(port, () => {
  console.log('Server started on: ' + port);
});