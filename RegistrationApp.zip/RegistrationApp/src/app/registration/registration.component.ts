import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ServicelistService } from '../servicelist.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  file: any;
id:any;
  constructor(public dialog: MatDialog, public service: ServicelistService,public router:Router) { }
  public myForm = new FormGroup({
    fname: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z \-\']+')]),
    lname: new FormControl('', [Validators.required]),
    pwd: new FormControl('', [Validators.required]),
    cpwd: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    img: new FormControl('', [Validators.required]),
    bdate: new FormControl('', [Validators.required]),
  })

  getErrorMessage() {
    if (this.myForm.value.email.hasError('required')) {
      return 'You must enter a value';
    }

    return this.myForm.value.email.hasError('email') ? 'Not a valid email' : '';
  }
  ngOnInit(): void {
  }

  registerSubmit() {
    var bday = new Date(this.myForm.value.bdate);

    var month = bday.getMonth() + 1;
    var day = bday.getDate();
    var year = bday.getFullYear();
    var birthDate = day + "/" + month + "/" + year;
    console.log("date", bday, month, day, year, birthDate);
    
    if (this.myForm.value.fname === '' || this.myForm.value.lname === '' || this.myForm.value.pwd === '' || this.myForm.value.cpwd === '' || this.myForm.value.email === '' || this.myForm.value.img === '' || this.myForm.value.bdate === '') {
      /* this.dialog.open(RDialog, {
        width: '250px',
        data: {msg:'Enter All Fields' }
      }); */
      alert("Enter All Fields")
    }
    else {
      console.log('form', this.myForm.value, this.file);
if(this.myForm.value.pwd === this.myForm.value.cpwd){


      var obj = {
        "firstName": this.myForm.value.fname,
        "lastName": this.myForm.value.lname,
        "password": this.myForm.value.pwd,
        "cpassword": this.myForm.value.cpwd,
        "email": this.myForm.value.email,
        "imageName": this.file.name,
        "birthdate": birthDate
      }
      this.service.postForm(this.myForm.value.fname,this.myForm.value.lname,this.myForm.value.pwd,this.myForm.value.cpwd,this.myForm.value.email,birthDate,this.file.name).subscribe(response=>{
        console.log('res form',response);
        this.router.navigate(['list']);
      })
    }
    else{
      alert("Password and Confirm password Should be Same")
    }
    }

  }
  onChangeImage(event) {
    this.file = event.target.files[0]
    console.log("file", this.file.name);
    console.log("file uploaded", this.file);
    this.service.postImage(event.target.files).subscribe(res => {
      console.log('resp', res);
     // const data =JSON.parse(res['_body']);
     // this.id = data.insertId;
    })
  }
}
@Component({
  selector: 'dialog-overview-example-dialog',
  templateUrl: 'r-dialog.html',
})
export class RDialog {

  constructor(
    public dialogRef: MatDialogRef<RegistrationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) { }



}
export interface DialogData {
  msg: string
}