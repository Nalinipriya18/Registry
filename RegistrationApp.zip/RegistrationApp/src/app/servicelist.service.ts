import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServicelistService {
  
  
  public headers = {
    'Content-Type': 'application/json',

  }
  constructor(public http: HttpClient) {

  }
  postImage(files:FileList) {
    var fileToUpload = files.item(0); 
    const formData = new FormData();
    console.log('file in service',fileToUpload,fileToUpload.name)
    formData.append('file',fileToUpload,fileToUpload.name);
    return this.http.post(`http://localhost:4000/postImage`,formData);
  }
  postForm(firstName, lastName,password,cpassword, email,birth_date,imageName) {
    return this.http.post(`http://localhost:4000/postRegistry`,{firstName:firstName,lastName:lastName,password:password,cpassword:cpassword,email:email,birth_date:birth_date,imageName:imageName},{headers:this.headers});
  }
  getRegistry() {
    return this.http.get("http://localhost:4000/getRegistryList");
  }
}
