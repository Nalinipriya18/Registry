import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListUserComponent } from './list-user/list-user.component';
import { RegistrationComponent } from './registration/registration.component';

const routes: Routes = [
  {
    path:'registry',
    component:RegistrationComponent
  },
  {
    path:'list',
    component:ListUserComponent
  },
  {
    path:'',redirectTo:'registry',pathMatch:'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
