import { Component, AfterViewInit, ViewChild } from '@angular/core'
import { MatPaginator } from '@angular/material/paginator'
import { MatTableDataSource } from '@angular/material/table'
import { ServicelistService } from '../servicelist.service'
import { Router } from '@angular/router'
@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements AfterViewInit {
  displayedColumns: string[] = [
    'rid',
    'imageName',
    'firstName',
    'lastName',
    'email',
    'birth_date'
  ]
  dataSource: any
  ELEMENT_DATA:any;
length:any;
  @ViewChild(MatPaginator) paginator: MatPaginator

  constructor (public service: ServicelistService, public router: Router) {}
  ngAfterViewInit () {
    this.service.getRegistry().subscribe(response    => {
      console.log('res registry', response)
 this.ELEMENT_DATA = response;
      this.dataSource = new MatTableDataSource<PeriodicElement>(this.ELEMENT_DATA);
     
        
        this.length = this.dataSource.length;
      this.dataSource.paginator = this.paginator
    })
  }
  back () {
    this.router.navigate(['/registry']);
  }
}

export interface PeriodicElement {
  firstName: string
  lastName:string;
  rid: number
  imageName: any
  birth_date: string
}


